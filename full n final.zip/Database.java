//package attr;

public class Database {
	public static final String HOST_URI = "jdbc:mysql://localhost:3306/bus";
	public static final String USER = "root";
	public static final String PASSWORD = "";
}